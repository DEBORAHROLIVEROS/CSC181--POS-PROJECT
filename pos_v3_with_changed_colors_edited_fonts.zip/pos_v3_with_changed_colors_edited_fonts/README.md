# CSC181--POS-PROJECT

#This is only the partial of our project. And every documents here might be revise in the future if needed.
